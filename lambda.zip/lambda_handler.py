"""
lambda_handler.py
-----------------
AWS Lambda entry point for the VA-Lambda Customer Data function.

Parses the incoming event, validates required fields, delegates to
response_merger, and returns an API-Gateway-compatible response.

All errors are logged as structured JSON to CloudWatch Logs.
Internal details are never exposed in HTTP error responses.
"""

import json
import logging
import traceback
import uuid
from datetime import datetime, timezone

from config import LOG_LEVEL
from response_merger import build_response


# ── Structured JSON logging (CloudWatch Insights compatible) ──────────────────

class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level":     record.levelname,
            "logger":    record.name,
            "message":   record.getMessage(),
            "function":  record.funcName,
            "line":      record.lineno,
        }
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_obj, ensure_ascii=False)


def _configure_logging() -> None:
    root = logging.getLogger()
    if root.handlers:
        for h in root.handlers:
            h.setFormatter(_JsonFormatter())
    else:
        h = logging.StreamHandler()
        h.setFormatter(_JsonFormatter())
        root.addHandler(h)
    root.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))


_configure_logging()
logger = logging.getLogger(__name__)


# ── HTTP response helpers ─────────────────────────────────────────────────────

def _ok(data: dict, request_id: str) -> dict:
    return {
        "statusCode": 200,
        "headers":    {"Content-Type": "application/json"},
        "body": json.dumps({"Data": data}),
    }


def _error(status_code: int, message: str, request_id: str) -> dict:
    return {
        "statusCode": status_code,
        "headers":    {"Content-Type": "application/json"},
        "body": json.dumps({
            "requestId": request_id,
            "status":    "error",
            "message":   message,
        }),
    }


# ── Input parsing & validation ────────────────────────────────────────────────

def _parse_event(event: dict) -> tuple[str, str]:
    """
    Extract CustomerId and FetchCustomerDataFlag from the event.

    Supports:
      - Direct Lambda invocation:   {"Data": {"CustomerId": "...", "FetchCustomerDataFlag": "N"}}
      - API Gateway proxy:          {"body": "<json string of above>"}

    Returns (customer_id, fetch_flag)
    Raises  ValueError on missing / invalid input.
    """
    # API Gateway wraps the body as a JSON string
    if "body" in event and isinstance(event["body"], str):
        try:
            payload = json.loads(event["body"])
        except json.JSONDecodeError as exc:
            raise ValueError("Request body is not valid JSON.") from exc
    else:
        payload = event

    data = payload.get("Data") or payload.get("data")
    if not data or not isinstance(data, dict):
        raise ValueError(
            "Missing 'Data' object. "
            'Expected: {"Data": {"CustomerId": "...", "FetchCustomerDataFlag": "Y|N"}}'
        )

    # Support both exact casing and common variants
    customer_id = (
        data.get("CustomerId")
        or data.get("customerid")
        or data.get("CustomerID")
        or data.get("customerId")
    )

    # Explicit key-presence check to avoid falsy suppression of valid values
    if "FetchCustomerDataFlag" in data:
        fetch_flag = data["FetchCustomerDataFlag"]
    elif "fetchCustomerDataFlag" in data:
        fetch_flag = data["fetchCustomerDataFlag"]
    elif "fetchcustomerdataflag" in data:
        fetch_flag = data["fetchcustomerdataflag"]
    else:
        fetch_flag = None

    if not customer_id:
        raise ValueError("'CustomerId' is required inside the Data object.")
    if fetch_flag is None:
        raise ValueError("'FetchCustomerDataFlag' is required inside the Data object.")

    return str(customer_id).strip(), str(fetch_flag).strip()


# ── Lambda handler ────────────────────────────────────────────────────────────

def handler(event: dict, context) -> dict:
    """
    AWS Lambda handler.

    Parameters
    ----------
    event   : dict  — API Gateway or direct-invocation payload
    context : LambdaContext — AWS runtime context
    """
    aws_request_id = getattr(context, "aws_request_id", None) or str(uuid.uuid4())

    logger.info(json.dumps({"event": "request_received", "requestId": aws_request_id}))

    # ── Parse & validate ──────────────────────────────────────────────────────
    try:
        customer_id, fetch_flag = _parse_event(event)
    except ValueError as exc:
        logger.warning(json.dumps({
            "event":     "validation_error",
            "requestId": aws_request_id,
            "detail":    str(exc),
        }))
        return _error(400, str(exc), aws_request_id)

    logger.info(json.dumps({
        "event":                "input_parsed",
        "requestId":            aws_request_id,
        "CustomerId":           customer_id,
        "FetchCustomerDataFlag": fetch_flag,
    }))

    # ── Build merged response ─────────────────────────────────────────────────
    try:
        result = build_response(customer_id, fetch_flag)

    except ValueError as exc:
        logger.warning(json.dumps({
            "event":     "invalid_flag",
            "requestId": aws_request_id,
            "detail":    str(exc),
        }))
        return _error(400, str(exc), aws_request_id)

    except RuntimeError as exc:
        logger.error(json.dumps({
            "event":     "downstream_error",
            "requestId": aws_request_id,
            "detail":    str(exc),
            "traceback": traceback.format_exc(),
        }))
        return _error(502, "A downstream service error occurred. Please try again.", aws_request_id)

    except Exception as exc:                            # pylint: disable=broad-except
        logger.critical(json.dumps({
            "event":     "unhandled_exception",
            "requestId": aws_request_id,
            "detail":    str(exc),
            "traceback": traceback.format_exc(),
        }))
        return _error(500, "An internal server error occurred.", aws_request_id)

    logger.info(json.dumps({
        "event":     "request_completed",
        "requestId": aws_request_id,
    }))
    return _ok(result, aws_request_id)
