"""
response_merger.py
------------------
Orchestrates API calls and maps source fields to the exact output schema.

Flag = "N"  (2 APIs → 8 fields, flat)
----------------------------------------------
Calls: customer/details  +  accounts/inquiry

Flag = "Y"  (3 APIs → nested KYCData structure)
----------------------------------------------
Calls: customer/details  +  accounts/inquiry  +  customer/fatca-crs

ClPreventTrading logic
----------------------
Scan all accounts returned by accounts/inquiry.
If ANY account has BOTH:
  - ProductCode  in PREVENT_TRADING_PRODUCT_CODES
  - StatusCode   in PREVENT_TRADING_STATUS_CODES
→ ClPreventTrading = "N"   (customer CAN trade — they have a qualifying account)
Otherwise → "Y"            (customer CANNOT trade)
"""

import logging
from typing import Any

from config import PREVENT_TRADING_PRODUCT_CODES, PREVENT_TRADING_STATUS_CODES
from api_client import call_customer_details, call_accounts_inquiry, call_fatca_crs

logger = logging.getLogger(__name__)


# ── ClPreventTrading helper ───────────────────────────────────────────────────

def _compute_cl_prevent_trading(accounts_response: dict) -> str:
    """
    Return "N" if ANY account satisfies both product-code and status-code
    criteria, else return "Y".
    """
    accounts = (
        accounts_response
        .get("Data", {})
        .get("Account", [])
    )
    if not isinstance(accounts, list):
        logger.warning("accounts/inquiry returned no Account list; defaulting ClPreventTrading=Y")
        return "Y"

    for acct in accounts:
        product_code = str(acct.get("ProductCode", "")).strip()
        status_code  = str(acct.get("StatusCode",  "")).strip()
        if (
            product_code in PREVENT_TRADING_PRODUCT_CODES
            and status_code  in PREVENT_TRADING_STATUS_CODES
        ):
            logger.info(
                "ClPreventTrading=N matched (ProductCode=%s, StatusCode=%s)",
                product_code, status_code,
            )
            return "N"

    logger.info("No qualifying account found; ClPreventTrading=Y")
    return "Y"


# ── Safe field extractor ──────────────────────────────────────────────────────

def _get(obj: dict, *keys, default="") -> Any:
    """Safely navigate nested dicts; return ``default`` on missing keys."""
    cur = obj
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k, default)
        if cur is None:
            return default
    return cur


# ── Flag = N  (8 fields) ──────────────────────────────────────────────────────

def _build_flag_n(customer_id: str, details: dict, accounts: dict) -> dict:
    """Map customer/details + accounts/inquiry → 8-field flat response."""
    personal = _get(details, "Data", "Customer", "CustomerPersonalDetails")
    info     = _get(personal, "PersonalInfo")     if personal else {}
    contact  = _get(personal, "ContactDetails")   if personal else {}
    kyc      = _get(personal, "KYCInfo")          if personal else {}

    cl_prevent_trading = _compute_cl_prevent_trading(accounts)

    return {
        "FullName":         _get(info,    "FullName"),
        "CustomerId":       customer_id,
        "MobileNumber":     _get(contact, "MobileNumber"),
        "Email":            _get(contact, "EmailId"),
        "ClaClientName":    _get(info,    "FullName"),
        "ClPreventTrading": cl_prevent_trading,
        "Nationality":      _get(info,    "NationalityCode"),
        "EmiratesId":       _get(kyc,     "UAENationalId"),
    }


# ── Flag = Y  (full KYCData structure) ───────────────────────────────────────

def _build_flag_y(customer_id: str, details: dict, accounts: dict, fatca_crs: dict) -> dict:
    """Map all three sources → nested KYCData response."""
    personal  = _get(details,   "Data", "Customer", "CustomerPersonalDetails")
    info      = _get(personal,  "PersonalInfo")   if personal else {}
    contact   = _get(personal,  "ContactDetails") if personal else {}
    kyc       = _get(personal,  "KYCInfo")        if personal else {}
    employer  = _get(personal,  "EmployerInfo")   if personal else {}

    cl_prevent_trading = _compute_cl_prevent_trading(accounts)

    # ── FATCA / CRS sources ───────────────────────────────────────────────────
    crs_data   = _get(fatca_crs, "Data", "CustomerCRS")
    fatca_data = _get(fatca_crs, "Data", "CustomerFATCA")

    crs_details  = _get(crs_data,  "CustomerDetails") if isinstance(crs_data, dict) else {}
    tax_residences = (
        crs_data.get("TaxResidenceCountryDetails", [])
        if isinstance(crs_data, dict) else []
    )

    # TaxResidence → list of TaxResidenceCountry strings (match sample output)
    tax_residence_list = [
        str(r.get("TaxResidenceCountry", ""))
        for r in tax_residences
        if isinstance(r, dict)
    ]

    # TINDetails: first entry's TaxpayerIdNumber
    tin_details = ""
    no_tin_reason = "0"
    if tax_residences:
        first = tax_residences[0] if isinstance(tax_residences[0], dict) else {}
        tin_details   = first.get("TaxpayerIdNumber", "")
        no_tin_reason = first.get("ReasonId", "0")

    # USPassport flag from FATCA
    us_passport_raw = ""
    if isinstance(fatca_data, dict):
        us_passport_raw = str(fatca_data.get("USPassportHolder", "NO")).upper()
    us_passport = us_passport_raw == "YES"

    # InternalAssessments — ClassificationId from CRS
    classification = _get(crs_details, "ClassificationId") if isinstance(crs_details, dict) else ""

    kyc_data = {
        # ── Personal from customer/details ────────────────────────────────────
        "FullName":         _get(info,    "FullName"),
        "Gender":           _get(info,    "Gender"),
        "Dob":              _get(info,    "DateofBirth"),
        "PlaceOfBirth":     _get(info,    "NationalityCode"),   # best available proxy
        "Nationality":      _get(info,    "NationalityCode"),
        # ── ID from KYCInfo ───────────────────────────────────────────────────
        "IdType":           _get(kyc,     "IdType"),
        "IdNumber":         _get(kyc,     "PassportNumber") or _get(kyc, "UAENationalId"),
        "IdExpiry":         _get(kyc,     "ExpiryDate"),
        # ── Address from ContactDetails ───────────────────────────────────────
        "AddressLine1":     _get(contact, "AddressLine1"),
        "AddressLine2":     _get(contact, "AddressLine2"),
        "City":             _get(contact, "City"),
        "State":            _get(contact, "State"),
        "Country":          _get(contact, "Country"),
        "PostalCode":       _get(contact, "AddressZip"),
        # ── Contact ───────────────────────────────────────────────────────────
        "Email":            _get(contact, "EmailId"),
        "Mobile":           _get(contact, "MobileNumber"),
        "Landline":         _get(contact, "HomeLandlineNumber") or _get(contact, "OfficeLandlineNumber"),
        # ── Employment ────────────────────────────────────────────────────────
        "EmploymentStatus": _get(employer, "EmploymentType"),
        # ── Compliance ────────────────────────────────────────────────────────
        "ClaClientName":    _get(info,    "FullName"),
        "ClPreventTrading": cl_prevent_trading,
        # ── Employer details ──────────────────────────────────────────────────
        "EmployerDetails": {
            "EmployerName":    _get(employer, "NameofEmployer"),
            "EmployerAddress": _get(employer, "EmploymentLocation"),
        },
        # ── Political Exposure (not in source APIs; defaults per sample) ──────
        "PoliticalExposure": {
            "IsPep":         False,
            "PositionHeld":  "",
            "RelatedToPep": {
                "IsRelated":    False,
                "PepName":      "",
                "Relationship": "",
            },
        },
        # ── FATCA / CRS ───────────────────────────────────────────────────────
        "FatcaCrs": {
            "USPassport":            us_passport,
            "TaxResidence":          tax_residence_list,
            "TINDetails":            tin_details,
            "NoTINReason":           no_tin_reason,
            "SpentMoreThan90Days":   False,
            "UndocumentedAccount":   False,
        },
        # ── Internal Assessments ──────────────────────────────────────────────
        "InternalAssessments": {
            "CustomerRiskScore": "Low",       # not provided by any API; use default
            "Classification":    str(classification),
        },
        # ── Screening / EDD / Tax ─────────────────────────────────────────────
        "ScreeningOutcomes": {
            "Details": "",
        },
        "EnhancedDueDiligence": {
            "IsEddCarriedOut": False,
            "Details":         "",
        },
        "TaxIdNumber": {
            "W9":      "",
            "SSNOrEIN": "",
        },
    }

    return {"KYCData": kyc_data}


# ── Public entry ──────────────────────────────────────────────────────────────

def build_response(customer_id: str, fetch_flag: str) -> dict[str, Any]:
    """
    Orchestrate API calls and return the merged Data payload.

    Parameters
    ----------
    customer_id : str
    fetch_flag  : str — "N" or "Y" (case-insensitive)

    Returns
    -------
    dict — content of the ``Data`` key in the final response

    Raises
    ------
    ValueError   — invalid fetch_flag
    RuntimeError — propagated from api_client on network/HTTP failure
    """
    flag = fetch_flag.strip().upper()
    if flag not in ("Y", "N"):
        raise ValueError(
            f"Invalid FetchCustomerDataFlag: '{fetch_flag}'. Expected 'Y' or 'N'."
        )

    logger.info(
        "build_response called — CustomerId=%s, FetchCustomerDataFlag=%s",
        customer_id, flag,
    )

    # Always required
    details  = call_customer_details(customer_id)
    accounts = call_accounts_inquiry(customer_id)

    if flag == "N":
        return _build_flag_n(customer_id, details, accounts)

    # flag == "Y" — also fetch FATCA/CRS
    fatca_crs = call_fatca_crs(customer_id)
    return _build_flag_y(customer_id, details, accounts, fatca_crs)
