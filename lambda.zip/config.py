"""
config.py
---------
All configuration for the VA-Lambda function.
Every hard-coded value lives here; override via Lambda environment variables.
"""

import os

# ── AWS / Secrets Manager ─────────────────────────────────────────────────────
SECRET_NAME = os.environ.get("SECRET_NAME", "va-lambda/client-credentials")
AWS_REGION  = os.environ.get("AWS_REGION",  "us-east-1")

# ── Downstream API Base URL ───────────────────────────────────────────────────
API_BASE_URL = os.environ.get(
    "API_BASE_URL",
    "https://devmaglan.adcbmis.local:8443"
)

# ── API Paths ─────────────────────────────────────────────────────────────────
API_CUSTOMER_DETAILS_PATH = os.environ.get(
    "API_CUSTOMER_DETAILS_PATH",
    "/v1/customer/details"
)
API_ACCOUNTS_INQUIRY_PATH = os.environ.get(
    "API_ACCOUNTS_INQUIRY_PATH",
    "/v1/accounts/inquiry"
)
API_FATCA_CRS_PATH = os.environ.get(
    "API_FATCA_CRS_PATH",
    "/v1/customer/fatca-crs"          # configure to real path when known
)

# ── OAuth2 Token Endpoint ─────────────────────────────────────────────────────
TOKEN_URL = os.environ.get(
    "TOKEN_URL",
    "https://devmaglan.adcbmis.local:8443/oauth2/token"
)

# ── HTTP Timeouts (seconds) ───────────────────────────────────────────────────
HTTP_CONNECT_TIMEOUT = int(os.environ.get("HTTP_CONNECT_TIMEOUT", "5"))
HTTP_READ_TIMEOUT    = int(os.environ.get("HTTP_READ_TIMEOUT",    "20"))

# ── Token Cache Buffer ────────────────────────────────────────────────────────
TOKEN_REFRESH_BUFFER = int(os.environ.get("TOKEN_REFRESH_BUFFER", "60"))

# ── SSL Verification ──────────────────────────────────────────────────────────
# Set to "false" (string) to disable self-signed cert verification in dev.
SSL_VERIFY = os.environ.get("SSL_VERIFY", "true").lower() != "false"

# ── ClPreventTrading Logic ────────────────────────────────────────────────────
# If an account has BOTH a matching ProductCode AND a matching StatusCode,
# ClPreventTrading = "N".  If NO account satisfies both conditions → "Y".
PREVENT_TRADING_PRODUCT_CODES = {
    "11", "20", "30", "41", "42", "43",
    "101", "105", "106", "107", "118", "119", "122",
    "132", "133", "135", "136", "141", "142", "146",
    "147", "148", "149", "165",
    "200", "201", "202", "203", "204", "206", "208",
    "211", "214", "217", "220", "230", "231", "234",
    "235", "237", "238", "239", "240", "241", "271",
    "290", "291", "292", "293", "294", "296", "298",
    "306", "307", "310", "311", "362", "385", "391",
    "398", "438", "455", "480", "485", "487",
    "871", "875", "904", "908", "909", "910", "913",
    "920", "935",
}

PREVENT_TRADING_STATUS_CODES = {"4", "6", "8", "16", "17", "3"}

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
