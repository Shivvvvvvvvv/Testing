"""
api_client.py
-------------
HTTP POST calls to the three ADCB downstream APIs.

All APIs accept POST with a JSON body {"Data": {"CustomerId": "..."}}
Bearer token is injected from auth.py; retries once on HTTP 401.
"""

import logging
from typing import Any

import requests
from requests.exceptions import RequestException, Timeout, HTTPError

from config import (
    API_BASE_URL,
    API_CUSTOMER_DETAILS_PATH,
    API_ACCOUNTS_INQUIRY_PATH,
    API_FATCA_CRS_PATH,
    HTTP_CONNECT_TIMEOUT,
    HTTP_READ_TIMEOUT,
    SSL_VERIFY,
)
from auth import get_access_token

logger = logging.getLogger(__name__)


# ── Internal helpers ──────────────────────────────────────────────────────────

def _build_headers(token: str) -> dict:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }


def _post(url: str, body: dict, api_name: str) -> dict[str, Any]:
    """
    Shared POST helper with unified error handling.
    Retries once with a fresh token on HTTP 401.
    """
    for attempt in range(2):
        token = get_access_token(force_refresh=(attempt == 1))
        try:
            response = requests.post(
                url,
                json=body,
                headers=_build_headers(token),
                timeout=(HTTP_CONNECT_TIMEOUT, HTTP_READ_TIMEOUT),
                verify=SSL_VERIFY,
            )

            if response.status_code == 401 and attempt == 0:
                logger.warning("[%s] 401 received — refreshing token and retrying.", api_name)
                continue

            response.raise_for_status()
            data = response.json()
            logger.info("[%s] Response received successfully.", api_name)
            return data

        except Timeout as exc:
            logger.error("[%s] Request timed out: %s", api_name, str(exc))
            raise RuntimeError(f"{api_name} timed out.") from exc

        except HTTPError as exc:
            status = getattr(exc.response, "status_code", "unknown")
            body_text = getattr(exc.response, "text", "")
            logger.error("[%s] HTTP %s error: %s", api_name, status, body_text)
            raise RuntimeError(f"{api_name} returned HTTP {status}.") from exc

        except RequestException as exc:
            logger.error("[%s] Request error: %s", api_name, str(exc))
            raise RuntimeError(f"{api_name} request failed: {exc}") from exc

    raise RuntimeError(f"{api_name} failed after token refresh retry.")


# ── Public API wrappers ───────────────────────────────────────────────────────

def call_customer_details(customer_id: str) -> dict[str, Any]:
    """
    POST /v1/customer/details
    Returns full CustomerPersonalDetails tree.
    """
    url  = f"{API_BASE_URL}{API_CUSTOMER_DETAILS_PATH}"
    body = {"Data": {"CustomerId": customer_id}}
    logger.info("Calling customer/details for CustomerId=%s", customer_id)
    return _post(url, body, api_name="customer/details")


def call_accounts_inquiry(customer_id: str) -> dict[str, Any]:
    """
    POST /v1/accounts/inquiry
    Returns list of Account objects with StatusCode and ProductCode.
    """
    url  = f"{API_BASE_URL}{API_ACCOUNTS_INQUIRY_PATH}"
    body = {"Data": {"CustomerId": customer_id}}
    logger.info("Calling accounts/inquiry for CustomerId=%s", customer_id)
    return _post(url, body, api_name="accounts/inquiry")


def call_fatca_crs(customer_id: str) -> dict[str, Any]:
    """
    POST /v1/customer/fatca-crs
    Returns CustomerCRS and CustomerFATCA data.
    Only invoked when FetchCustomerDataFlag == "Y".
    """
    url  = f"{API_BASE_URL}{API_FATCA_CRS_PATH}"
    body = {"Data": {"CustomerId": customer_id}}
    logger.info("Calling customer/fatca-crs for CustomerId=%s", customer_id)
    return _post(url, body, api_name="customer/fatca-crs")
