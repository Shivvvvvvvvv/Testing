"""
secrets_manager.py
------------------
Fetches client credentials (client_id / client_secret) from AWS Secrets Manager.
Results are cached per Lambda execution environment (warm start reuse).

LOCAL TESTING BYPASS
---------------------
Set the following environment variables to skip AWS entirely:
  LOCAL_CLIENT_ID     = any string
  LOCAL_CLIENT_SECRET = any string
"""

import os   # needed for local bypass (boto3 import is deferred below)

import json
import logging
from botocore.exceptions import ClientError

from config import SECRET_NAME, AWS_REGION

logger = logging.getLogger(__name__)

# Module-level cache — persists across warm invocations
_cached_secret: dict | None = None


def get_client_credentials(force_refresh: bool = False) -> dict:
    """
    Return {'client_id': ..., 'client_secret': ...}.

    LOCAL MODE: if LOCAL_CLIENT_ID and LOCAL_CLIENT_SECRET env vars are set,
    returns them directly without any AWS call.

    Parameters
    ----------
    force_refresh : bool
        If True, bypass the in-memory cache and fetch fresh credentials.

    Returns
    -------
    dict
        Keys: ``client_id``, ``client_secret``

    Raises
    ------
    RuntimeError
        Wraps any Secrets Manager or JSON parsing error.
    """
    global _cached_secret

    # ── Local bypass ──────────────────────────────────────────────────────────
    local_id     = os.environ.get("LOCAL_CLIENT_ID")
    local_secret = os.environ.get("LOCAL_CLIENT_SECRET")
    if local_id and local_secret:
        logger.info("LOCAL MODE: using LOCAL_CLIENT_ID / LOCAL_CLIENT_SECRET env vars.")
        return {"client_id": local_id, "client_secret": local_secret}

    # ── AWS Secrets Manager ───────────────────────────────────────────────────
    if _cached_secret and not force_refresh:
        logger.debug("Returning cached client credentials.")
        return _cached_secret

    logger.info("Fetching client credentials from Secrets Manager: %s", SECRET_NAME)
    import boto3  # deferred so local runs don't need AWS credentials

    client = boto3.client("secretsmanager", region_name=AWS_REGION)
    try:
        response = client.get_secret_value(SecretId=SECRET_NAME)
    except ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        logger.error(
            "Secrets Manager error [%s] while fetching '%s': %s",
            error_code, SECRET_NAME, str(exc),
        )
        raise RuntimeError(
            f"Failed to retrieve secret '{SECRET_NAME}': {error_code}"
        ) from exc

    secret_string = response.get("SecretString") or ""
    try:
        secret_data = json.loads(secret_string)
    except json.JSONDecodeError as exc:
        logger.error("Secrets Manager secret is not valid JSON: %s", str(exc))
        raise RuntimeError("Secret value is not valid JSON.") from exc

    # Validate required keys
    required_keys = {"client_id", "client_secret"}
    if not required_keys.issubset(secret_data):
        missing = required_keys - secret_data.keys()
        raise RuntimeError(
            f"Secret '{SECRET_NAME}' is missing required keys: {missing}"
        )

    _cached_secret = {
        "client_id":     secret_data["client_id"],
        "client_secret": secret_data["client_secret"],
    }
    return _cached_secret
