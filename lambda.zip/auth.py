"""
auth.py
-------
OAuth2 client-credentials token management.

Tokens are cached in module-level state so warm Lambda invocations
reuse the same token until it is close to expiry.

LOCAL TESTING BYPASS
---------------------
Set LOCAL_ACCESS_TOKEN to any non-empty string to skip the token endpoint
entirely.  The value is passed as the Bearer token to downstream APIs.

    LOCAL_ACCESS_TOKEN=local-test-token
"""

import logging
import os
import time

import requests
from requests.exceptions import RequestException

from config import TOKEN_URL, HTTP_CONNECT_TIMEOUT, HTTP_READ_TIMEOUT, TOKEN_REFRESH_BUFFER
from secrets_manager import get_client_credentials

logger = logging.getLogger(__name__)

# Module-level token cache
_token_cache = {
    "access_token": None,
    "expires_at":   0.0,   # Unix timestamp
}


def _is_token_valid() -> bool:
    """Return True if the cached token exists and is not near expiry."""
    return (
        _token_cache["access_token"] is not None
        and time.time() < _token_cache["expires_at"] - TOKEN_REFRESH_BUFFER
    )


def get_access_token(force_refresh: bool = False) -> str:
    """
    Return a valid OAuth2 Bearer token.

    Fetches a new token from ``TOKEN_URL`` using client credentials obtained
    from Secrets Manager.  The result is cached so subsequent warm invocations
    skip the token endpoint call.

    Parameters
    ----------
    force_refresh : bool
        Bypass the cache and always request a new token.

    Returns
    -------
    str
        A valid Bearer token string.

    Raises
    ------
    RuntimeError
        On network failures or unexpected token endpoint responses.
    """
    # ── Local bypass ──────────────────────────────────────────────────────────
    local_token = os.environ.get("LOCAL_ACCESS_TOKEN")
    if local_token:
        logger.info("LOCAL MODE: using LOCAL_ACCESS_TOKEN env var — skipping token endpoint.")
        return local_token

    # ── Token cache ───────────────────────────────────────────────────────────
    if not force_refresh and _is_token_valid():
        logger.debug("Reusing cached access token.")
        return _token_cache["access_token"]

    logger.info("Requesting new access token from %s", TOKEN_URL)
    credentials = get_client_credentials()

    try:
        response = requests.post(
            TOKEN_URL,
            data={
                "grant_type":    "client_credentials",
                "client_id":     credentials["client_id"],
                "client_secret": credentials["client_secret"],
            },
            timeout=(HTTP_CONNECT_TIMEOUT, HTTP_READ_TIMEOUT),
        )
        response.raise_for_status()
    except RequestException as exc:
        logger.error("Token request failed: %s", str(exc))
        raise RuntimeError(f"Unable to obtain access token: {exc}") from exc

    token_data = response.json()

    access_token = token_data.get("access_token")
    expires_in   = token_data.get("expires_in", 3600)  # default 1 hour

    if not access_token:
        raise RuntimeError("Token endpoint returned no 'access_token'.")

    _token_cache["access_token"] = access_token
    _token_cache["expires_at"]   = time.time() + expires_in

    logger.info("New access token acquired, expires in %s seconds.", expires_in)
    return access_token
